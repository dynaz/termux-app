##
## This script is sourced by /data/data/com.terminow/files/usr/bin/login before executing shell.
##
