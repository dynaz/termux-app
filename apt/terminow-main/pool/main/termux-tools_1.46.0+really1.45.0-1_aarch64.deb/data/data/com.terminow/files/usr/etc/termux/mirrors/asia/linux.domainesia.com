# This file is sourced by pkg
# TermiNow | https://dynaz.github.io/termux-app/apt
WEIGHT=1
MAIN="https://dynaz.github.io/termux-app/apt/terminow-main"
ROOT="https://dynaz.github.io/termux-app/apt/terminow-root"
X11="https://dynaz.github.io/termux-app/apt/terminow-x11"
