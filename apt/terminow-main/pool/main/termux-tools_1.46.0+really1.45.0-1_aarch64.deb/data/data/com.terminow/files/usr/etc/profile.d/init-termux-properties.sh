if [ ! -f /data/data/com.terminow/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.terminow/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.terminow/files/home/.termux
	cp /data/data/com.terminow/files/usr/share/examples/termux/termux.properties /data/data/com.terminow/files/home/.termux/
fi
