export TMUX_TMPDIR=/data/data/com.terminow/files/usr/var/run
