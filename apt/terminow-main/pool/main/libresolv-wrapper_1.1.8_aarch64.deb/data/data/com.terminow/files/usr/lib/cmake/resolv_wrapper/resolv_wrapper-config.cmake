set(RESOLV_WRAPPER_LIBRARY /data/data/com.terminow/files/usr/lib/libresolv_wrapper.so)
