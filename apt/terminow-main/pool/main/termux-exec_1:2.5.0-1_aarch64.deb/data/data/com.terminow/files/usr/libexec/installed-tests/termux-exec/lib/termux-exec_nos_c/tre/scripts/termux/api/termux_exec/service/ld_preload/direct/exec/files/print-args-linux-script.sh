#!/data/data/com.terminow/files/usr/bin/sh

echo "$@"
